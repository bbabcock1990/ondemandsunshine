Configuration install_apps
{
    Import-DscResource -Module cChoco
    Node "localhost"
    {
        
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        cChocoInstaller InstallChoco
        {
            # required!
            InstallDir = 'c:\choco'
        }

        cChocoPackageInstallerSet InstallBaselinePackages
        {
            Name      = 'googlechrome', 'sunshine', 'cemu'
            Ensure    = 'present'
            DependsOn = '[cChocoInstaller]InstallChoco'
        }

        SetScript = {
            $sunshine_config = "https://github.com/bbabcock1990/ondemandsunshine/raw/main/sunshine_config.zip"
            Invoke-Webrequest -Uri $sunshine_config -OutFile "C:\Program Files\Sunshine\config\sunshine_config.zip"
            Expand-Archive -LiteralPath 'C:\Program Files\Sunshine\config\sunshine_config.zip' -DestinationPath 'C:\Program Files\Sunshine\config' -Force
        }
        TestScript = return $true
        GetScript = {}

    }
}