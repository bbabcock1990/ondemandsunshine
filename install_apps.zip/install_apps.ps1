Configuration install_apps
{
    Node "localhost"
    {
        File CreateFolder
        {
            Type            = 'Directory'
            DestinationPath = 'C:\Apps'
            Ensure          = "Present"
        }
    }
}