Configuration install_apps
{
    Import-DscResource -Module cChoco
    Node "localhost"
    {
        
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        Script Install_Net
        {
            SetScript = {
                $SourceURI = "https://download.visualstudio.microsoft.com/download/pr/2d6bb6b2-226a-4baa-bdec-798822606ff1/8494001c276a4b96804cde7829c04d7f/ndp48-x86-x64-allos-enu.exe"
                $FileName = $SourceURI.Split('/')[-1]
                $BinPath = Join-Path $env:SystemRoot -ChildPath "Temp\$FileName"
                if (!(Test-Path $BinPath))
                {
                    Invoke-Webrequest -Uri $SourceURI -OutFile $BinPath
                }
                write-verbose "Installing .Net 4.5.2 from $BinPath"
                write-verbose "Executing $binpath /q /restart"
                Sleep 5
                Start-Process -FilePath $BinPath -ArgumentList "/q /restart" -Wait -NoNewWindow            
                Sleep 5
            }

            TestScript = {
                return $true
            }

            GetScript = {
              
            }
        }

        cChocoInstaller InstallChoco
        {
            # required!
            InstallDir = 'c:\choco'
            DependsOn = '[Script]Install_Net'
        }
        cChocoPackageInstallerSet InstallBaselinePackages
        {
            Name      = 'googlechrome', 'git', 'putty'
            Ensure    = 'present'
            DependsOn = '[cChocoInstaller]InstallChoco'
        }
    }
}