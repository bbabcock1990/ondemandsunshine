Configuration install_apps
{
    Import-DscResource -Module cChoco
    Node "localhost"
    {
        
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        cChocoInstaller InstallChoco
        {
            # required!
            InstallDir = 'c:\choco'
            DependsOn = '[Script]Install_Net'
        }
        cChocoPackageInstallerSet InstallBaselinePackages
        {
            Name      = 'googlechrome', 'sunshine'
            Ensure    = 'present'
            DependsOn = '[cChocoInstaller]InstallChoco'
        }
    }
}