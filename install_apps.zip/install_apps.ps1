Configuration install_apps
{
    Node "localhost"
    {
        File CreateFolder
        {
            Type            = 'Directory'
            DestinationPath = 'C:\Apps'
            Ensure          = "Present"
        }
        cChocoInstaller InstallChoco
        {
            # required!
            InstallDir = 'c:\choco'
        }
        cChocoPackageInstallerSet InstallBaselinePackages
        {
            Name      = 'googlechrome', 'git', 'putty'
            Ensure    = 'present'
            DependsOn = '[cChocoInstaller]InstallChoco'
        }
    }
}